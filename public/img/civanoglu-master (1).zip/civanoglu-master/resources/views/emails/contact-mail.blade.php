<p>Hello {{$contact->name}},</p>

<p>We have received your message. This is what you sent.</p>

<p>
    Name: {{$contact->name}}<br/>
    Email: {{$contact->email}}<br/>
    Phone: {{$contact->phone}}<br/>
    Message: {{$contact->message}}<br/>
</p>


<p>We will reply you soon. In the meanwhile you can call us following number.</p>
